from django.apps import AppConfig


class LibmsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "LIBMS"
